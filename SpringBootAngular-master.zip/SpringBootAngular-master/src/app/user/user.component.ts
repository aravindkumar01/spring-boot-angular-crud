import { Component, OnInit } from '@angular/core';
import { User } from './model/user';
import { UserserviceService } from './service/userservice.service';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {

  
  user:User=new User();
  submitted = false;
  constructor(private service:UserserviceService) { }

  ngOnInit() {
   
  }

  newUser(): void {
    this.submitted = false;
    this.user=new User();
  }

  save() {
    
    this.service.createUser(this.user)
      .subscribe(
        data => {
          alert(data);
          this.submitted = true;
        },
        error => {
          console.log(error);
         // alert(JSON.stringify(error.text));
          
        }
        );
    this.user = new User();
    
  }

  onSubmit() {
    this.submitted = true;
    this.save();
  }
 
}
