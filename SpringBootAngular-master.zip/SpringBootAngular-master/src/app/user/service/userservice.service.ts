import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { User } from '../model/user';
import { HttpHeaders } from '@angular/common/http';

const httpOptions = {
  headers: new HttpHeaders({
    'Content-Type':  'application/json'
  })
};

@Injectable({
  providedIn: 'root'
})
export class UserserviceService {
 
  constructor(private http: HttpClient) { }

  private baseUrl="http://localhost:8081/user";

  getUser(name: string): Observable<any> {
    return this.http.get(`${this.baseUrl}/${name}`);
  }
  createUser(user: any): Observable<any> {
    console.log(user);
    return this.http.post(this.baseUrl, user);
  }


  getUsersList(): Observable<any> {
    return this.http.get(this.baseUrl);
  }
}
