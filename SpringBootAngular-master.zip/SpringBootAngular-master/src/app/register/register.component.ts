import { Component, OnInit } from '@angular/core';
import { UserserviceService } from '../user/service/userservice.service';
import { Observable } from 'rxjs';
import { User } from '../user/model/user';


@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  users:Observable<User[]>;
  user:User = new User();
  userId:number=0;
  userName:string="";
  userEmail:string="";
  userPassword:string="";
  constructor(private service:UserserviceService) { }

  ngOnInit() {
    
    this.reloadData();
  }


  reloadData() {
    this.users = this.service.getUsersList();
    
  }

  
  userSearch(search:string)   
  {
     
    this.users=this.service.getUser(search);
    console.log(this.users);
    //this.reloadData();
  }


  userView(user:any){
    let myDiv = document.getElementById('myModal');
    myDiv.focus;
    this.userId=user.id;    
    this.userName=user.name;
    this.userEmail=user.email;
    this.userPassword=user.password;
        this.reloadData();
     //console.log(user);
    

  }

  userDelete()
  {

  }


  save() {
    
    this.service.createUser(this.user)
      .subscribe(
        data => {
          alert(data);
         
        },
        error => {
          console.log(error);
         // alert(JSON.stringify(error.text));
          
        }
        );
    this.user = new User();
    
  }

  onSubmit() {
    alert('SUCCESS!! :-)\n\n' + JSON.stringify(this.user, null, 4));
    this.save();
    console.log(this.user.id);
    console.log(this.user.name);
  }
}
