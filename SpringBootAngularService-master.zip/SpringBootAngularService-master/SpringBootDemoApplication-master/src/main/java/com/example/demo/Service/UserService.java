package com.example.demo.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.Entity.User;
import com.example.demo.Repo.UserRepo;

@Service
public class UserService {

@Autowired
UserRepo repo;

 public String add(User user) 
 {
	 
	 try {
		 repo.save(user);
		   return "sucess";
	} catch (Exception e) {
		return e.toString();
		// TODO: handle exception
	}
	 
 }

public List<User> getUsers() {
	// TODO Auto-generated method stub
	try {
		
		return repo.findAll();
	} catch (Exception e) {
		System.out.println(e);
		// TODO: handle exception
	}
	return null;
}

public List<User> findByname(String name) {
	
	try {
		return repo.findByName(name);
	} catch (Exception e) {
		System.out.println(e);
		// TODO: handle exception
	}
	return null;
}
 
}
