package com.example.demo.Repo;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import com.example.demo.Entity.User;

public interface UserRepo extends JpaRepository<User, Long>{

	@Transactional
    @Modifying
    @Query("select c from User c where c.name = :name")		
	List<User> findByName(String name);

}
