package com.example.demo.Controller;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.example.demo.Entity.User;
import com.example.demo.Service.UserService;

@Controller
@CrossOrigin ("http://localhost:4200")
public class UserController {
	
	

	public static final Logger logger = LoggerFactory.getLogger(UserController.class);
	@Autowired
	UserService service;
	
	/*
	 * @RequestMapping(value="/user",method=RequestMethod.POST) public @ResponseBody
	 * String add(@RequestBody User user) {
	 * 
	 * try { String result=service.add(user); return result;
	 * 
	 * } catch (Exception e) { // TODO: handle exception return e.toString(); }
	 * 
	 * }
	 */
	@PostMapping(value = "/user")
	  public ResponseEntity<String> postCustomer(@RequestBody User user) {
	    try {
	     String u= service.add(user);
	      return new ResponseEntity<String>(u, HttpStatus.CREATED);
	    } catch (Exception e) {
	      return new ResponseEntity<>(null, HttpStatus.EXPECTATION_FAILED);
	    }
	  }
	@GetMapping("/user")
	 public ResponseEntity<List<User>> getAllCustomers() {
	    List<User> customers = new ArrayList<>();
	    try {
	     // repository.findAll().forEach(customers::add);
	    	customers=service.getUsers();
	      
	      if (customers.isEmpty()) {
	        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
	      }
	      return new ResponseEntity<>(customers, HttpStatus.OK);
	    } catch (Exception e) {
	      return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
	    }
}

	

	 @GetMapping("/user/{name}")
	    public  ResponseEntity<List<User>> getUser(@PathVariable("name") String name) {
	     
		 try {
				List<User> user =service.findByname(name);
		        if (user.isEmpty()) {
		            return new ResponseEntity(HttpStatus.NO_CONTENT);
		            // You many decide to return HttpStatus.NOT_FOUND
		        }
		        return new ResponseEntity<List<User>>(user, HttpStatus.OK);
				
			} catch (Exception e) {
				System.out.println(e);
				// TODO: handle exception
			}
		return null;
		   
	    }
}